/**import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class BaiduSearchTest {

    WebDriver driver;

    @BeforeMethod
    public void setUp() {
        // 直接用 System.setProperty 指定 EdgeDriver 的路径
        System.setProperty("webdriver.edge.driver", "C:\\Users\\test\\Downloads\\edgedriver_win64\\msedgedriver.exe");
        driver = new EdgeDriver();
        driver.manage().window().maximize();
    }

    @Test
    public void testSearch() throws InterruptedException {
        driver.get("https://www.sogou.com");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("kw")));
        driver.findElement(By.id("kw")).sendKeys("软件测试");
        driver.findElement(By.id("su")).click();
        Thread.sleep(2000);
        System.out.println("页面标题：" + driver.getTitle());
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}**/
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SogouSearchTest {

    WebDriver driver;
    SogouPage sogouPage;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.edge.driver", "C:\\Users\\test\\Downloads\\edgedriver_win64\\msedgedriver.exe");
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        sogouPage = new SogouPage(driver);
    }

    @Test
    public void testSearch() {
        String url = ConfigReader.getBaseUrl();
        String keyword = ConfigReader.getSearchKeyword();

        sogouPage.open();
        sogouPage.inputKeyword(keyword);
        sogouPage.clickSearch();
        sogouPage.waitForTitleContains(keyword);

        System.out.println("页面标题：" + sogouPage.getTitle());
    }

    @AfterMethod
    public void tearDown() {
      //  if (driver != null) driver.quit();
    }
}