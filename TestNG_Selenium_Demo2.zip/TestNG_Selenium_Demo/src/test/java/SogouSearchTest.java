import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.*;
import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.*;
import org.testng.Assert;
public class SogouSearchTest {

    WebDriver driver;
    SogouPage sogouPage;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.edge.driver", "C:\\Users\\test\\Downloads\\edgedriver_win64\\msedgedriver.exe");
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        sogouPage = new SogouPage(driver);
    }
    @DataProvider(name = "searchData")
    public Object[][] provideSearchData() {
        return new Object[][] {
                {"软件测试"},
                {"自动化测试"},
                {"性能测试"},
                {"安全测试"}
        };
    }
    @Test(dataProvider = "searchData")
    public void testSearch(String keyword) {
        String url = ConfigReader.getBaseUrl();


        sogouPage.open();
        sogouPage.inputKeyword(keyword);
        sogouPage.clickSearch();
        sogouPage.waitForTitleContains(keyword);

        String actualTitle = sogouPage.getTitle();
        Assert.assertTrue(actualTitle.contains(keyword),
                "搜索 [" + keyword + "] 失败，实际标题：" + actualTitle);

        System.out.println("搜索 [" + keyword + "] 通过，标题：" + actualTitle);
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
           // driver.quit();
        }
    }
}