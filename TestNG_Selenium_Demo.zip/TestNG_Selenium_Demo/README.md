# Sogou 搜索自动化测试框架

## 项目简介
这是一个基于 **Java + Selenium + TestNG** 的 Web 自动化测试框架，以搜狗搜索为被测对象，演示了从环境搭建到用例执行的完整流程。

## 技术栈
- Java 11
- Selenium WebDriver
- TestNG
- Log4j 2
- Maven
- CSV 数据驱动

## 框架特点
- **POM 设计模式**：页面与测试逻辑分离
- **数据驱动**：测试数据存放在 CSV 文件中，与代码解耦
- **日志**：Log4j 2 记录执行过程，支持 INFO/DEBUG/ERROR 级别
- **失败截图**：断言失败时自动截图，保存到 `test-output/screenshots/`
- **测试报告**：TestNG 生成 HTML 报告，位于 `test-output/html/index.html`

## 快速开始

### 环境要求
- JDK 11+
- Maven 3.6+
- Edge 浏览器

### 运行步骤
1. 克隆项目到本地
2. 修改 `src/test/resources/config.properties` 中的 EdgeDriver 路径
3. 在项目根目录执行：`mvn clean test`
4. 或直接在 IDEA 中右键 `testng.xml` → Run

### 查看报告
- 测试报告：`test-output/html/index.html`
- 失败截图：`test-output/screenshots/`

## 项目结构
### src/test/java
- pages # POM 页面类
- tests # 测试类
- utils # 工具类
### src/test/resources
- testdata.csv
- config.properties
- log4j2.xml


## 作者
 唐云宁

