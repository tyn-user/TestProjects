import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.*;
import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.*;
import org.testng.Assert;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestResult;

import java.io.File;

public class SogouSearchTest {
    private static final Logger logger = LogManager.getLogger(SogouSearchTest.class);
    WebDriver driver;
    SogouPage sogouPage;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.edge.driver", "C:\\Users\\test\\Downloads\\edgedriver_win64\\msedgedriver.exe");
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        sogouPage = new SogouPage(driver);
    }
    @DataProvider(name = "searchData")
    public Object[][] provideSearchData() {
        return CsvReader.getData("testdata.csv");
    }
    @Test(dataProvider = "searchData")
    public void testSearchWithData(String keyword) {
        logger.info("开始搜索，关键词：{}", keyword);

        sogouPage.open();
        logger.debug("打开搜狗首页");

        sogouPage.inputKeyword(keyword);
        sogouPage.clickSearch();
        sogouPage.waitForTitleContains(keyword);

        String actualTitle = sogouPage.getTitle();
        logger.info("获取到的页面标题：{}", actualTitle);

        Assert.assertTrue(actualTitle.contains(keyword),
                "搜索 [" + keyword + "] 失败，实际标题：" + actualTitle);

        logger.info("搜索 [{}] 通过", keyword);
    }
    // 在 tearDown 之前加一个截图方法
    private void takeScreenshot(String testName) {
        if (driver == null) return;
        try {
            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            String timestamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date());
            String fileName = testName + "_" + timestamp + ".png";
            File destFile = new File("test-output/screenshots/" + fileName);
            FileUtils.copyFile(srcFile, destFile);
            logger.info("截图已保存：" + destFile.getAbsolutePath());
        } catch (Exception e) {
            logger.error("截图失败：" + e.getMessage());
        }
    }

    @AfterMethod
    public void tearDown(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            logger.error("测试失败：" + result.getName());
            takeScreenshot(result.getName());
        }
        if (driver != null) {
            //driver.quit();
        }
    }
}