import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class SogouPage {
    private WebDriver driver;
    private WebDriverWait wait;

    public SogouPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void open() {
        driver.get("https://www.sogou.com");
    }

    public void inputKeyword(String keyword) {
        wait.until(ExpectedConditions.elementToBeClickable(By.id("query")));
        driver.findElement(By.id("query")).sendKeys(keyword);
    }

    public void clickSearch() {
        wait.until(ExpectedConditions.elementToBeClickable(By.id("stb")));
        driver.findElement(By.id("stb")).click();
    }

    public String getTitle() {
        return driver.getTitle();
    }
}