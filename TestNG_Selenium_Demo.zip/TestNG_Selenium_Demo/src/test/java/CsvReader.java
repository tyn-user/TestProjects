import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class CsvReader {

    public static Object[][] getData(String fileName) {
        try (InputStream is = CsvReader.class.getClassLoader().getResourceAsStream(fileName);
             BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {

            List<Object[]> dataList = new ArrayList<>();
            String line;
            boolean isFirstLine = true;

            while ((line = reader.readLine()) != null) {
                // 跳过表头
                if (isFirstLine) {
                    isFirstLine = false;
                    continue;
                }
                // 跳过空行
                if (line.trim().isEmpty()) continue;

                String keyword = line.trim();
                dataList.add(new Object[]{keyword});
            }
            return dataList.toArray(new Object[0][]);

        } catch (Exception e) {
            throw new RuntimeException("读取 CSV 失败：" + fileName, e);
        }
    }
}