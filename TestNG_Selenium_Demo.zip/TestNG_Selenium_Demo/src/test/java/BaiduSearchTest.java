/**import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class BaiduSearchTest {

    WebDriver driver;

    @BeforeMethod
    public void setUp() {
        // 直接用 System.setProperty 指定 EdgeDriver 的路径
        System.setProperty("webdriver.edge.driver", "C:\\Users\\test\\Downloads\\edgedriver_win64\\msedgedriver.exe");
        driver = new EdgeDriver();
        driver.manage().window().maximize();
    }

    @Test
    public void testSearch() throws InterruptedException {
        driver.get("https://www.sogou.com");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.elementToBeClickable(By.id("kw")));
        driver.findElement(By.id("kw")).sendKeys("软件测试");
        driver.findElement(By.id("su")).click();
        Thread.sleep(2000);
        System.out.println("页面标题：" + driver.getTitle());
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}**/
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.time.Duration;

public class BaiduSearchTest {

    WebDriver driver;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.edge.driver", "C:\\Users\\test\\Downloads\\edgedriver_win64\\msedgedriver.exe");
        driver = new EdgeDriver();
        driver.manage().window().maximize();
    }

    @Test
    public void testSearch() throws InterruptedException {
        driver.get("https://www.baidu.com");

        // 等待页面加载完成
        Thread.sleep(3000);

        // 用 JavaScript 直接给搜索框赋值（绕过任何浮层干扰）
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("document.getElementById('kw').value = '软件测试'");

        // 同样用 JavaScript 直接点击搜索按钮
        js.executeScript("document.getElementById('su').click()");

        Thread.sleep(2000);
        System.out.println("当前页面标题：" + driver.getTitle());
        System.out.println("当前页面URL：" + driver.getCurrentUrl());
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
           // driver.quit();
        }
    }
}