import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class BaiduSearchTest {

    WebDriver driver;

    @BeforeEach
    public void setUp() {
        System.setProperty("webdriver.edge.driver", "C:\\Users\\唐云宁\\Desktop\\edgedriver\\msedgedriver.exe");
        System.setProperty("selenium manager", "false");

        EdgeOptions options = new EdgeOptions();
        options.addArguments("--remote-allow-origins=*");
        // 添加这行，避免被百度识别为自动化工具
        options.addArguments("--disable-blink-features=AutomationControlled");

        driver = new EdgeDriver(options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize(); // 最大化窗口，避免元素被遮挡
    }

    @Test
    public void testSearch() {
        driver.get("https://www.baidu.com");

        // 方法1：先用JavaScript给搜索框赋值
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("document.getElementById('kw').value = '软件测试'");

        // 方法2：再点击搜索按钮（同样用JS）
        js.executeScript("document.getElementById('su').click()");

        // 等待页面标题变化
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.titleContains("软件测试"));

        String pageTitle = driver.getTitle();
        assertTrue(pageTitle.contains("软件测试"), "页面标题应该包含“软件测试”");
        System.out.println("测试通过！页面标题：" + pageTitle);
    }

    @AfterEach
    public void tearDown() {
        if (driver != null) {
           // driver.quit();
        }
    }
}